package Imoveis;

public class ValorNullOuValorNegativoException extends RuntimeException {
	
	public ValorNullOuValorNegativoException(String message){
		super(message);
	}
}
